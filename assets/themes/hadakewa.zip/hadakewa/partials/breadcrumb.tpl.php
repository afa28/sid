<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php if ($this->breadcrumbs->generate_breadcrumb()):?>
	<?php echo $this->breadcrumbs->generate_breadcrumb();?><?php endif;?>
